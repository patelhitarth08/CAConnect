from django.apps import AppConfig


class CaadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CAadmin'
